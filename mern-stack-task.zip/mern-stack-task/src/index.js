const express = require('express');
const morgan = require('morgan');
const path = require('path');

const { mongoose } = require('./database');

const app = express();

// Configuracion
app.set( 'port', process.env.PORT || 3000);

// Middlewares (funciones antes que se ejecuten en nuestras rutas)
app.use(morgan('dev'));
app.use(express.json());

// Routes
app.use('/api/tasks', require('./routes/task.routes'));

// Archivos estaticos

app.use(express.static(path.join(__dirname, 'public')));

// Inicia el servidor

app.listen(app.get('port'), () => {
    console.log(`Server on port ${app.get('port')}`);
});